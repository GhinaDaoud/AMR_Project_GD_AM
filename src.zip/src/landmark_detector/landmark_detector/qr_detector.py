import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from geometry_msgs.msg import PoseStamped
import cv2
from pyzbar.pyzbar import decode
import json
import os
import math

class QRDetectorNode(Node):
    def __init__(self):
        super().__init__('qr_detector')
        
        # Subscribe to camera
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10
        )
        
        # Subscribe to robot pose
        self.pose_subscription = self.create_subscription(
            PoseStamped,
            '/robot_pose',
            self.pose_callback,
            10
        )
        
        self.bridge = CvBridge()
        self.current_pose = None
        self.detected_landmarks = {}
        
        # Landmark database file
        self.db_path = os.path.expanduser('~/ros2_ws/landmark_db.json')
        
        # Load existing landmarks if any
        if os.path.exists(self.db_path):
            with open(self.db_path, 'r') as f:
                self.detected_landmarks = json.load(f)
            self.get_logger().info(f'Loaded {len(self.detected_landmarks)} existing landmarks')
        
        self.get_logger().info('QR Detector Node started')

    def pose_callback(self, msg):
        self.current_pose = msg.pose

    def image_callback(self, msg):
        try:
            # Convert ROS image to OpenCV
            cv_image = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            
            # Decode QR codes
            qr_codes = decode(cv_image)
            
            for qr in qr_codes:
                # Get QR content
                landmark_name = qr.data.decode('utf-8')
                
                # Draw on image
                points = qr.polygon
                if points:
                    pts = [(p.x, p.y) for p in points]
                    for i in range(len(pts)):
                        cv2.line(cv_image, pts[i], pts[(i+1) % len(pts)],
                                (0, 255, 0), 2)
                
                cv2.putText(cv_image, landmark_name,
                           (qr.rect.left, qr.rect.top - 10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                
                # Store landmark position
                if landmark_name not in self.detected_landmarks:
                    if self.current_pose:
                        position = {
                            'x': self.current_pose.position.x,
                            'y': self.current_pose.position.y,
                            'z': self.current_pose.position.z
                        }
                    else:
                        position = {'x': 0.0, 'y': 0.0, 'z': 0.0}
                    
                    self.detected_landmarks[landmark_name] = position
                    self.get_logger().info(
                        f'NEW LANDMARK: {landmark_name} at {position}')
                    
                    # Save to file
                    self.save_landmarks()
            
            # Show image
            cv2.imshow('QR Detector', cv_image)
            cv2.waitKey(1)
            
        except Exception as e:
            self.get_logger().error(f'Error: {str(e)}')

    def save_landmarks(self):
        with open(self.db_path, 'w') as f:
            json.dump(self.detected_landmarks, f, indent=2)
        self.get_logger().info(f'Saved {len(self.detected_landmarks)} landmarks to {self.db_path}')

def main(args=None):
    rclpy.init(args=args)
    node = QRDetectorNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
